package com.spring.foodoredr;

public class Restaurant {
    private String name;
    private String location;
    private String[] availableCuisines;

    public Restaurant(String name, String location, String[] availableCuisines) {
        this.name = name;
        this.location = location;
        this.availableCuisines = availableCuisines;
    }

    public boolean servesCuisine(String cuisine) {
        for (String c : availableCuisines) {
            if (c.equalsIgnoreCase(cuisine)) {
                return true;
            }
        }
        return false;
    }

    public String getName() {
        return name;
    }
}
