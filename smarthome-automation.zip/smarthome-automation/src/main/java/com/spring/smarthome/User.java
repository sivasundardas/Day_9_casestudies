package com.spring.smarthome;

import org.springframework.stereotype.Component;

@Component
public class User {
    private String name = "Sundar";
    private String homeId = "Home101";

    public String getName() {
        return name;
    }

    public String getHomeId() {
        return homeId;
    }
}
