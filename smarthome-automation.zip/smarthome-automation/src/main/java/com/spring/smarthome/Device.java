package com.spring.smarthome;

import org.springframework.stereotype.Component;

@Component
public class Device {
    private String deviceType = "Light";
    private String status = "Off";

    public void turnOn() {
        status = "On";
        System.out.println(deviceType + " turned " + status);
    }

    public void turnOff() {
        status = "Off";
        System.out.println(deviceType + " turned " + status);
    }
}
